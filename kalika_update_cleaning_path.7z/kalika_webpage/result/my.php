<html>
<body>
<?php
	echo read_file("hello");
?>
</body>
</html>
