function abc()
		{
			document.write("success");
		}