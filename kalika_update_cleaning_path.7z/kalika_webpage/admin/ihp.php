<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		h1 {
			text-align:center;
			color:yellow;
		}
		body {
                        height: 100%;
                        background-position: revert;
                        background-repeat: no-repeat;
                        background-size: cover;
	}
	</style>
	<script>
		function abc() {
			alert("You completed Input process !!!");
		}
	</script>
	<title></title>
</head>
<body background="../img/indexs.png" onload="abc()">
<?php
$cookieadminuser = file_get_contents("../s3cUr3adminuser");
$cookieadminpass = file_get_contents("../s3cUr3adminpass");
if (($_COOKIE["user"] == preg_replace('/\s+/', '', $cookieadminuser)) and ($_COOKIE["pass"] == preg_replace('/\s+/', '', $cookieadminpass))) {
        // nothing to do crediential is correct for admin user
}
else {
        header("Location:../home.php");
}
$section = $_POST['section'];
$class = $_POST['class'];
$bdate = $_POST['bdate'];
$hwtitle = $_POST['hwtitle'];
$subject = $_POST['subject'];
chdir("datas");
if (0==file_exists($class))	{
	mkdir($class);
}
chdir($class);
if (0==file_exists($section)) {
	mkdir($section);
}
chdir($section);
if (0==file_exists($subject)) {
	mkdir($subject);
}
chdir($subject);
if (0==file_exists($bdate)) {
	mkdir($bdate);
}
chdir($bdate);
file_put_contents("hwtitle.txt",$hwtitle);
?>
</body>
</html>
