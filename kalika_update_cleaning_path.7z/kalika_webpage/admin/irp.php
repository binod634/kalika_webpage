<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		h1 {
			text-align:center;
		}
	</style>
	<title></title>
</head>
<body>
<?php
$cookieadminuser = file_get_contents("../s3cUr3adminuser");
$cookieadminpass = file_get_contents("../s3cUr3adminpass");
if (($_COOKIE["user"] == preg_replace('/\s+/', '', $cookieadminuser)) and ($_COOKIE["pass"] == preg_replace('/\s+/', '', $cookieadminpass))) {
        // nothing to do crediential is correct for admin user
}
else {
        header("Location:../home.php");
}
$name = $_POST['bname'];
$symbol = $_POST['bsym'];
$percentage = $_POST['bper'];
$position = $_POST['bpost'];
if (0==file_exists('datar'))	{
	mkdir('datar');
}
chdir('datar');
if (0==file_exists($symbol)) {
	mkdir($symbol);
}
chdir($symbol);
file_put_contents("name.txt",$name);
file_put_contents("percentage.txt",$percentage);
file_put_contents("position.txt",$position);
echo "<h1>You Completed inputting result !!!</h1>";
?>
</body>
</html>
