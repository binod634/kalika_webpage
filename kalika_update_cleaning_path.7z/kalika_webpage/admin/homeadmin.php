<html>
<head><title>Kalika Manavgyan Student Database</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
h1 {
text-align:center;
margin-top:15%;
color:darkred;
}
table.m {
width:70%;
text-align:center;
margin:auto;
}
table.o {
border-margin-left:100%;
margin-left:auto;
border-color:white;
}
input {
border:white;
font-weight:bold;
}
input:hover {
background-color:black;
color:yellow;
}
b {
color:blue;
margin-top:15%;
}
body {
	background-size: cover;
	background-repeat: no-repeat;
}
</style>
<script type="text/javascript">
function abc() {
	alert("You are already in Home Page!!!");
}
function inputresult() {
	window.location.href="inputresult.php";
}
function inputhomework() {
    window.location.href="inputhomework.php";
}
function homework() {
    window.location.href="../result/homework.php";              // fix this
}
function result() {
	window.location.href="../result/result.php";
}
function logout() {
	window.location.href="../index.php";
}
function about() {
	window.location.href="../about.php";
}
</script>
</head>
<body background="../img/home.png">
<?php
$cookieadminuser = file_get_contents("../s3cUr3adminuser");
$cookieadminpass = file_get_contents("../s3cUr3adminpass");
if (($_COOKIE["user"] == preg_replace('/\s+/', '', $cookieadminuser)) and ($_COOKIE["pass"] == preg_replace('/\s+/', '', $cookieadminpass))) {
        // nothing to do crediential is correct for admin user
}
else {
        header("Location:../home.php");
}
?>
<table class="o">
	<tr><b>
		<td>
			 <input type="button" class="text" onclick="abc()" value="Home">
		</td>
		<td>
			<input type="button"  onclick="inputhomework()" class="text" value="Input HW">
		</td>
		<td>
			<input type="button"  onclick="inputresult()" class="text" value="Input Result">
		</td>
		<td>
			<input type="button"  onclick="result()" class="text" value="Get RESULT">
		</td>
		<td>
			<input type="button"  onclick="homework()" class="text" value="Get HOMEWORK">
		</td>
		<td>
			<input type="button" onclick="about()" class="text" value="About">
		</td>
		<td>
			<input type="button" onclick="logout()" class="text" value="Log Out">
    	</td>
    	</b>
	</tr>
</table>
<h1> KALIKA STUDENT DATABASE</h1>
<table class='m'>
	<tr>
		<td>
			<b>Kalika Manavgyan Secondary School was established with the motto of imparting quality education. It is well facilitated community school. We offer both general and technical education. Under general education, we have classes from Nursery to class 12. We offer class 1 to 4 fully English medium and 5 to 12 in both English and Nepali medium. We have Science, Management, Humanities, Education, Law, and Computer Engineering streams in class 11 and 12. In technical education, we offer class 9 to 12 Computer Engineering. We believe in strong base of students. So, we are conducting Kalika Montessori Programme. Now we have 5529 students. We are maintaining well balance between both quantity and quality. Kalika Manavgyan Secondary School is also recognized as Model Community School by Government of Nepal. We are able to establish Kalika Manavgyan as International School as it has been awarded "AN INTERNATIONAL SCHOOL AWARD 2016-19" by British Council. It is continuously standing in the first position in Nepal in technical SLC and SEE (2071 to 2074). Now, in general also we have got first position in Nepal (2073) and National Third Position in 2074. At last, we would like to request you to visit Kalika Manavgyan Secondary School. We are always wishing to welcome you here.</b>
		</td>
	</tr>
</table>

</body>
</html>
