<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		body {
			background-color:lightblue;
		}
		h1 {
			text-align:center;
			color:gray;
			font-weight:bold;
		}
		h1.auto {
			background-color:red;
		}
		input {
			padding-right:80px;
			padding-left:80px;
			padding-bottom:40px;
			padding-top:40px;
			margin-left: 22%;
			margin-top:5%;
		}
		input.f {
			background-color:blue;
			transition-delay:1s;
		}
		input.f:hover {
			background-color:gray;
		}
		input.s {
			background-color:yellow;
		}
		input.s:hover {
			background-color:gray;
		}
	</style>
	<title>Result List</title>
</head>
<body>
		<h1> RESULT CENTRE </h1>
			<h1 class="top"> !!! Please define the RESULT type !!! </h1>
	<input type="Button" onclick="location.href = 'result/homework.php';" value="HOMEWORK" class="f">
	<input type="button" onclick="location.href = 'result/result.php';" value="RESULT" class="s"><br>
</body>
</html>