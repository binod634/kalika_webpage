<!DOCTYPE html>
<html lang="en" >
  <head>
    <meta charset="utf-8">
    <title>Animated Login Kalika</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <?php 
    setcookie("user",false);
    setcookie("pass",false);
    file_put_contents("hello.txt","pass");
    echo file_get_contents("hello.txt");
    ?>
<form class="box" action="home.php" method="post">
  <h1>Login</h1>
  <br>
  <input type="text"  name="username" oninvalid="this.setCustomValidity('Fill and retry ...')"   oninput="setCustomValidity('')"placeholder="username" required="">
  <br>
  <input type="password" oninvalid="this.setCustomValidity('Fill and retry ...')"  oninput="setCustomValidity('')" name="password" placeholder="password" required="">
  <br>
  <input type="submit" name="" value="Login">
</form>
  </body>
</html>
