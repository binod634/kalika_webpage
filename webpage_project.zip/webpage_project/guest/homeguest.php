<html>
<head><title>Kalika Manavgyan Student Database</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
<style type="text/css">
	body {

		 background:;
     height: 1200px;
		  background-size: cover;
    background-position: center;

		}

	a{
		text-decoration:none ;
  }	
  .kalika{
		color: brown;
		font-family: algerian;
		margin-left: 28%;
	    margin-right: 25%;
	    font-size: 30px;
	}
  ul{
   list-style-type: none;
   margin: 0px;
   padding: 0px;
  
   }
nav ul li ul li.different{
	background-color: white;
}
.edit{
	height: 850px;
	width:150px;
	background: black;
	background-color: black;
	text-align: center;
	margin-top: 0px;
	}
.text{
	
	color: white;
	font-size: 25px;
	font-family: monospace;
}
.paragraph{
		font-family:Calibri Light;
		font-size: 20px;
		margin-left: 200px;
	}
	.home{
		border-color: yellow;
	}
.textrs{
	
	color: black;
	font-size: 25px;
	font-family: monospace;
	}
  .textr{
  
  color: red;
  font-size: 30px;
  font-family:algerian;
  }
	.edit li:hover{
		border-bottom: dashed;
		border-bottom-color:white;
	}
	.edit ul li ul li:hover{
     background-color:purple;
}

.edit li:hover{
     background-color: blue; 
}
li a.text:hover{
     color:yellow;
     font-size:35px;
     font-weight: bold;


}
 ul li ul {

 	display: none;
 	background-color: white;
 	border-top: dotted;
 	border-top-color: green;
 	
 }

 ul li:hover ul {

 	display: block;
 	 background-color:black;
 	
 }    
   #big{
 	font-size: 30px;
 	margin-top: 0px;
 }
 img.contact{
 	height:40px;
 	width: 40px;
 }
 img.contact:hover{
 	height:40px;
 	width: 40px;
 	cursor: pointer;
 }
i{
  border:solid white;
  border-width: 0 4px 4px 0;
  display:inline-block;
  padding: 5px;
}
.down{
 transform: rotate(45deg);
}
	.paragraph{
		font-family:Calibri Light;
		font-size: 20px;
	}
	h1{
		color: red;
		font-size: 50px;
		background: lightblue;
		margin-left: 20%;
	    margin-right: 36%;
	    font-family: Comic Sans MS;
		
	}
	.kalika{
		color: brown;
		font-family: algerian;
		margin-left: 28%;
	    margin-right: 25%;
	    font-size: 30px;
	    list-style: none;

	}
	form{
		
	    margin-right: 29%;
	}
	 
.title {
  width: 1500px;
  height: 90px;
  background-color: white;
  position: relative;
  animation-name: example;
  animation-duration: 3s;
}

@keyframes example {
  0%   {background-color:white; left:0px; top:0px;}
  25%  {background-color:white; left:200px; right:0px;}
  50%  {background-color:white; left:200px; right:200px;}
  75%  {background-color:white; left:0px; right:200px;}
  100% {background-color:white; left:0px; right:0px;}
}

.yolast{
	color: blue;
}
</style>
<script type="text/javascript">
	function abc() {
		alert("You are already in Home Page!!!");
	}
	function unauthorized() {
		alert("You are not Admin !!!");
		alert("Your IP Address is Reported to Admin...");
	}
</script>
</head>
<body>
<?php
$cookieguestuser = file_get_contents("../s3cUr3guestuser");
$cookieguestpass = file_get_contents("../s3cUr3guestpass");
$cookieadminuser = file_get_contents("../s3cUr3adminuser");
$cookieadminpass = file_get_contents("../s3cUr3adminpass");
if (($_COOKIE["user"] == preg_replace('/\s+/', '', $cookieadminuser)) and ($_COOKIE["pass"] == preg_replace('/\s+/', '', $cookieadminpass))) {
        // nothing to do crediential is correct for admin user
}
else if (($_COOKIE["user"] == preg_replace('/\s+/', '', $cookieguestuser)) and ($_COOKIE["pass"] == preg_replace('/\s+/', '', $cookieguestpass))) {
        // nothing to do crediential is correct for guest user
}
else {
        header("Location:../home.php");
}
?>
	<div class="title"><h1>Kalika Students Database</h1></div>
	
	
	
	<u class="kalika">Kalika Manavgan Secondary School</u>
<h3 class="paragraph">

Kalika Manavgyan Secondary School was established with the motto of imparting quality education. It is well facilitated community school. We offer both general and technical education. Under general education, we have classes from Nursery to class 12. We offer class 1 to 4 fully English medium and 5 to 12 in both English and Nepali medium. We have Science, Management, Humanities, Education, Law, and Computer Engineering streams in class 11 and 12. In technical education, we offer class 9 to 12 Computer Engineering. We believe in strong base of students. So, we are conducting Kalika Montessori Programme. Now we have 5529 students. We are maintaining well balance between both quantity and quality. Kalika Manavgyan Secondary School is also recognized as Model Community School by Government of Nepal. We are able to establish Kalika Manavgyan as International School as it has been awarded "AN INTERNATIONAL SCHOOL AWARD 2016-19" by British Council. It is continuously standing in the first position in Nepal in technical SLC and SEE (2071 to 2074). Now, in general also we have got first position in Nepal (2073) and National Third Position in 2074. At last, we would like to request you to visit Kalika Manavgyan Secondary School. We are always wishing to welcome you here.</h3>
	<form>
			<div class="edit">
	<ul><li>
		<a class="text" onclick="abc()"> HOME</a></li>
	    <li><a href="../result.php" class="text">Result</a></li>
        <li><a onclick="unauthorized()" class="text">Input</a></li> 
        <li><a href="../index.php"class="text">logout</a></li>
        <li><a href="../about.php" class="text"> About</li>
   		<li><h5><a class="text" href="http://www.kalikaschoolbtl.edu.np/" >KALIKA SCHOOL</a></h5></li>
        </ul>
    </div>
</body>
</html>
