<!DOCTYPE html>
<html>
<head>
<style>
h1 {
	text-align:center;
}
table {
	text-align: center;
	margin: auto;
}
</style>
	<title></title>
</head>
<body>
<h1> -> RESULT <- </h1>
<table border='2'>
	<tr>
		<td>
			<?php
			$cookieguestuser = file_get_contents("../s3cUr3guestuser");
			$cookieguestpass = file_get_contents("../s3cUr3guestpass");
			$cookieadminuser = file_get_contents("../s3cUr3adminuser");
			$cookieadminpass = file_get_contents("../s3cUr3adminpass");
			if (($_COOKIE["user"] == preg_replace('/\s+/', '', $cookieadminuser)) and ($_COOKIE["pass"] == preg_replace('/\s+/', '', $cookieadminpass))) {
			        // nothing to do crediential is correct for admin user
			}
			else if (($_COOKIE["user"] == preg_replace('/\s+/', '', $cookieguestuser)) and ($_COOKIE["pass"] == preg_replace('/\s+/', '', $cookieguestpass))) {
			        // nothing to do crediential is correct for guest user
			}
			else {
			        header("Location:../home.php");
			}
			$symbol = $_POST['bsym'];
			chdir("../admin/datar");
			if (0==file_exists($symbol))	{
			echo "NO DATA FOUND";
			}
			else {
				chdir($symbol);
				echo "NAME: ";
				echo file_get_contents("name.txt");
				echo "<br>PERCENTAGE: ";
				echo file_get_contents("percentage.txt");
				echo "<br>POSITION: ";
				echo file_get_contents("position.txt");
			}
			?>
		</td>
	</tr>
</table>
</body>
</html>
