<!DOCTYPE html>
<html>
<head>
<style>
h1 {
	text-align:center;
}
p {
	color:red;
}
table {
	text-align: center;
	margin: auto;
}
</style>
	<title></title>
</head>
<body>
<h1> -> HOMEWORK <- </h1>
<table border='2'>
	<tr>
		<td>
			<?php
			$cookieguestuser = file_get_contents("../s3cUr3guestuser");
			$cookieguestpass = file_get_contents("../s3cUr3guestpass");
			$cookieadminuser = file_get_contents("../s3cUr3adminuser");
			$cookieadminpass = file_get_contents("../s3cUr3adminpass");
			if (($_COOKIE["user"] == preg_replace('/\s+/', '', $cookieadminuser)) and ($_COOKIE["pass"] == preg_replace('/\s+/', '', $cookieadminpass))) {
			        // nothing to do crediential is correct for admin user
			}
			else if (($_COOKIE["user"] == preg_replace('/\s+/', '', $cookieguestuser)) and ($_COOKIE["pass"] == preg_replace('/\s+/', '', $cookieguestpass))) {
			        // nothing to do crediential is correct for guest user
			}
			else {
			        header("Location:../home.php");
			}
			$date = $_POST['bdate'];
			$sec = $_POST['bsec'];
			$class = $_POST['bclass'];
			$sub = $_POST['bsub'];
			chdir("../admin/datas");
			if (0==file_exists($class))	{
				echo "NO DATA FOUND";
			}
			else {
				chdir($class);
				if(0==file_exists($sec)) {
					echo "YOUR CLASS SECTION DO NOT EXIST IN DATABASE";
				}
				else {
					chdir($sec);
					if (0==file_exists($sub)) {
						echo "THE DATABASE CONTAIN NO HOMEWORK FOR THIS SUBJECT: ";
						echo $sub;
					}
					else {
						chdir($sub);
						if(0==file_exists($date)) {
							echo "THE DATABASE CONTAIN NO HOMEWORK IN THIS DATE: ";
						}
						else {
							chdir($date);
							echo "HOMEWORK: <p>";
							echo  file_get_contents("hwtitle.txt");
							echo "</p>";
						}
					}
				}
			}
			?>
		</td>
	</tr>
</table>
</body>
</html>
